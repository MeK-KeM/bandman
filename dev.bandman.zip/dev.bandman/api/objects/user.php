<?php
class User{

    // database connection and table name
    private $conn;
    private $table_name = "users";

    // object properties
    public $id;
    public $name;
    public $phone;
    public $bio;
    public $pass;

    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // read users
    function read(){

        // select all query
        $query = "SELECT p.id, p.name, p.phone, p.bio, p.pass, p.firstname
            FROM
                " . $this->table_name . " p
            ORDER BY
                p.id DESC";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        // execute query
        $stmt->execute();

        return $stmt;
    }

    // read one user
    function readOne(){

        // query to read single record
        $query = "SELECT p.id, p.name, p.phone, p.bio, p.pass, p.firstname
            FROM
                " . $this->table_name . " p
                WHERE
                p.id = ?";

        // prepare query statement
        $stmt = $this->conn->prepare( $query );

        // bind id of product to be updated
        $stmt->bindParam(1, $this->id);

        // execute query
        $stmt->execute();

        // get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // set values to object properties
        $this->name = $row['name'];
        $this->phone = $row['phone'];
        $this->bio = $row['bio'];
        $this->pass = $row['pass'];
        $this->firstname = $row['firstname'];
    }

    // create user
    function create(){

        // query to insert record
        $query = "INSERT INTO
                " . $this->table_name . "
            SET name=:name, phone=:phone, pass=:pass, bio=:bio, firstname=:firstname";


        // prepare query
        $stmt = $this->conn->prepare($query);

        // sanitize
        $this->name=htmlspecialchars(strip_tags($this->name));
        $this->phone=htmlspecialchars(strip_tags($this->phone));
        $this->bio=htmlspecialchars(strip_tags($this->bio));
        $this->pass=htmlspecialchars(strip_tags($this->pass));
        $this->firstname=htmlspecialchars(strip_tags($this->firstname));

        // bind values
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":phone", $this->phone);
        $stmt->bindParam(":bio", $this->bio);
        $stmt->bindParam(":pass", $this->pass);
        $stmt->bindParam(":firstname", $this->firstname);

        // execute query
        if($stmt->execute()){
            return true;
        }

        return false;

    }

    // update users
    function update($newAttributes){
        if (empty($newAttributes)) {
            return false;
        }

        // update query
        /*$query = "UPDATE
                " . $this->table_name . "
            SET
                phone = :phone,
                bio = :bio,
                pass = :pass
            WHERE
                name = :name";*/

        $query = "UPDATE " . $this->table_name . " SET ";
        $i = 0;
        foreach ($newAttributes as $attr) {
            $query .= ($i==0)? "": ",";
            $query .= "{$attr} = :{$attr}";
            $i++;
        }
        $query .= " WHERE name = :name";


        // prepare query statement
        $stmt = $this->conn->prepare($query);

        function setVarInQuery($_attr, $stmt, $obj) {
            if ( $_attr == 'bio' ) {
                $obj->bio=htmlspecialchars(strip_tags($obj->bio));
                $stmt->bindParam(':bio', $obj->bio);
            }
            if ( $_attr == 'phone' ) {
                $obj->phone=htmlspecialchars(strip_tags($obj->phone));
                $stmt->bindParam(':phone', $obj->phone);
            }
            if ( $_attr == 'pass' ) {
                $obj->pass=htmlspecialchars(strip_tags($obj->pass));
                $stmt->bindParam(':pass', $obj->pass);
            }
            if ( $_attr == 'firstname' ) {
                $obj->firstname=htmlspecialchars(strip_tags($obj->firstname));
                $stmt->bindParam(':firstname', $obj->firstname);
            }

        }

        // sanitize
        $this->name=htmlspecialchars(strip_tags($this->name));

        // bind new values
        $stmt->bindParam(':name', $this->name);


        if (in_array('phone', $newAttributes)) {
            setVarInQuery('phone', $stmt, $this);
        }
        if (in_array('bio', $newAttributes)) {
            setVarInQuery('bio', $stmt, $this);
        }
        if (in_array('pass', $newAttributes)) {
            setVarInQuery('pass', $stmt, $this);
        }
        if (in_array('firstname', $newAttributes)) {
            setVarInQuery('firstname', $stmt, $this);
        }

        // execute the query
        if($stmt->execute()) {
            return true;
        }

        return false;
    }

}