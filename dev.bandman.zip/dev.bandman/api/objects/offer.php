<?php
class Offer{

    // database connection and table name
    private $conn;
    private $table_name = "offers";

    // object properties
    public $id;
    public $title;
    public $sender_id;
    public $receiver_id;
    public $start_date;
    public $finish_date;
    public $description;
    public $status;

    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // read products
    function read($user_id){

        // select all query
        $query = "SELECT p.id, p.title, p.sender_id, p.receiver_id, p.start_date, p.finish_date, p.description, p.status
            FROM
                " . $this->table_name . " p
                WHERE p.receiver_id = $user_id OR p.sender_id = $user_id
            ORDER BY
                p.id ASC";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        // execute query
        $stmt->execute();

        return $stmt;
    }

    // read products
    function readOne(){

        // query to read single record
        $query = "SELECT p.id, p.title, p.sender_id, p.receiver_id, p.start_date, p.finish_date, p.description, p.status
            FROM
                " . $this->table_name . " p
                WHERE p.id = ?";

        // prepare query statement
        $stmt = $this->conn->prepare( $query );

        // bind id of product to be updated
        $stmt->bindParam(1, $this->id);

        // execute query
        $stmt->execute();

        // get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // set values to object properties
        $this->title = $row['title'];
        $this->sender_id = $row['sender_id'];
        $this->receiver_id = $row['receiver_id'];
        $this->start_date = $row['start_date'];
        $this->finish_date = $row['finish_date'];
        $this->description = $row['description'];
        $this->status = $row['status'];
    }

    // create product
    function create(){

//         query to insert record
        $query = "INSERT INTO 
                " . $this->table_name . "
            SET title=:title, sender_id=:sender_id, receiver_id=:receiver_id , start_date=:start_date,
             finish_date=:finish_date, description=:description, status=:status";


        // prepare query
        $stmt = $this->conn->prepare($query);

        // sanitize
        $this->title=htmlspecialchars(strip_tags($this->title));
        $this->sender_id= (int) htmlspecialchars(strip_tags($this->sender_id));
        $this->receiver_id= (int) htmlspecialchars(strip_tags($this->receiver_id));
        $this->start_date=htmlspecialchars(strip_tags($this->start_date));
        $this->finish_date=htmlspecialchars(strip_tags($this->finish_date));
        $this->description=htmlspecialchars(strip_tags($this->description));
        $this->status = (int)htmlspecialchars(strip_tags($this->status));

        // bind values
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":sender_id", $this->sender_id);
        $stmt->bindParam(":receiver_id", $this->receiver_id);
        $stmt->bindParam(":start_date", $this->start_date);
        $stmt->bindParam(":finish_date", $this->finish_date);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":status", $this->status);

        // execute query
        if($stmt->execute()){
            return true;
        }

        return false;

    }

    // update query
    function update($newAttributes){
        if (empty($newAttributes)){return false;}

        $query = "UPDATE " . $this->table_name . " SET ";
        $i = 0;
        foreach ($newAttributes as $attr) {
            $query .= ($i==0)? "": ",";
            $query .= "{$attr} = :{$attr}";
            $i++;
        }
        $query .= " WHERE id = :id";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        // sanitize
        function setVarInQuery($_attr, $stmt, $obj) {
            if ( $_attr == 'title' ) {
                $obj->title=htmlspecialchars(strip_tags($obj->title));
                $stmt->bindParam(':title', $obj->title);
            }
            if ( $_attr == 'start_date' ) {
                $obj->start_date=htmlspecialchars(strip_tags($obj->start_date));
                $stmt->bindParam(':start_date', $obj->start_date);
            }
            if ( $_attr == 'finish_date' ) {
                $obj->finish_date=htmlspecialchars(strip_tags($obj->finish_date));
                $stmt->bindParam(':finish_date', $obj->finish_date);
            }
            if ( $_attr == 'sender_id' ) {
                $obj->sender_id=htmlspecialchars(strip_tags($obj->sender_id));
                $stmt->bindParam(':sender_id', $obj->sender_id);
            }
            if ( $_attr == 'receiver_id' ) {
                $obj->receiver_id=htmlspecialchars(strip_tags($obj->receiver_id));
                $stmt->bindParam(':receiver_id', $obj->receiver_id);
            }
            if ( $_attr == 'description' ) {
                $obj->description=htmlspecialchars(strip_tags($obj->description));
                $stmt->bindParam(':description', $obj->description);
            }
            if ( $_attr == 'status' ) {
                $obj->status=htmlspecialchars(strip_tags($obj->status));
                $stmt->bindParam(':status', $obj->status);
            }

        }
        // sanitize
        $this->id=htmlspecialchars(strip_tags($this->id));

        // bind new values
        $stmt->bindParam(':id', $this->id);


        if (in_array('title', $newAttributes)) {
            setVarInQuery('title', $stmt, $this);
        }
        if (in_array('sender_id', $newAttributes)) {
            setVarInQuery('sender_id', $stmt, $this);
        }
        if (in_array('receiver_id', $newAttributes)) {
            setVarInQuery('receiver_id', $stmt, $this);
        }
        if (in_array('start_date', $newAttributes)) {
            setVarInQuery('start_date', $stmt, $this);
        }
        if (in_array('finish_date', $newAttributes)) {
            setVarInQuery('finish_date', $stmt, $this);
        }
        if (in_array('description', $newAttributes)) {
            setVarInQuery('description', $stmt, $this);
        }
        if (in_array('status', $newAttributes)) {
            setVarInQuery('status', $stmt, $this);
        }

        // execute the query
        if($stmt->execute()){
            return true;
        }

        return false;
    }
}