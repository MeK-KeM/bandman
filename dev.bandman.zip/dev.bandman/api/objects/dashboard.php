<?php
class Dashboard{

    // database connection and table name
    private $conn;
    private $table_name = "dashboard";

    // object properties
    public $id;
    public $offer_id;
    public $sender_id;
    public $receiver_id;

    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

    // read products
    function read($user_id){

        // select all query
        $query = "SELECT p.id, p.offer_id, p.sender_id, p.receiver_id 
            FROM
                " . $this->table_name . " p
                WHERE p.receiver_id = $user_id OR p.sender_id = $user_id
            ORDER BY
                p.id ASC";

        // prepare query statement
        $stmt = $this->conn->prepare($query);

        // execute query
        $stmt->execute();

        return $stmt;
    }
}