<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// get database connection
include_once '../config/database.php';

// instantiate product object
include_once '../objects/offer.php';

$database = new Database();
$db = $database->getConnection();

$offers = new Offer($db);

// get posted data
$data = json_decode(file_get_contents("php://input"));

// make sure data is not empty
if(
    !empty($data->title) &&
    !empty($data->sender_id) &&
    !empty($data->receiver_id) &&
    !empty($data->start_date)&&
    !empty($data->finish_date)&&
    !empty($data->description)&&
    !empty($data->status)
){

    // set product property values
    $offers->title = $data->title;
    $offers->sender_id = $data->sender_id;
    $offers->receiver_id = $data->receiver_id;
    $offers->start_date= $data->start_date;
    $offers->finish_date= $data->finish_date;
    $offers->description = $data->description;
    $offers->status = $data->status;

    // create the product
    if($offers->create()){

        // set response code - 201 created
        http_response_code(201);

        // tell the user
        echo json_encode(array("result" => "1"));
    }

    // if unable to create the product, tell the user
    else{

        // set response code - 503 service unavailable
        http_response_code(503);

        // tell the user
        echo json_encode(array("result" => "0"));
    }
}

// tell the user data is incomplete
else{

    // set response code - 400 bad request
    http_response_code(400);

    // tell the user
    echo json_encode(array("message" => "Unable to create product. Data is incomplete."));
}
?>