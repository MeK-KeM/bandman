<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// database connection will be here

// include database and object files
include_once '../config/database.php';
include_once '../objects/offer.php';

// instantiate database and offer object
$database = new Database();
$db = $database->getConnection();

// initialize object
$offer = new Offer($db);

// read offers will be here
$offer_id = isset($_GET['id']) ? $_GET['id'] : die();
// query offers
$offer->id = $offer_id;
$stmt = $offer->readOne();


// check if more than 0 record found
if($offer->id!=null){
    // create array
    $offer_arr = array(
        "id" =>  $offer->id,
        "title" => $offer->title,
        "sender_id" => $offer->sender_id,
        "receiver_id" => $offer->receiver_id,
        "start_date" => $offer->start_date,
        "finish_date" => $offer->finish_date,
        "description" => $offer->description,
        "status"=> $offer->status
    );

    // set response code - 201 OK
    http_response_code(201);

    // make it json format
    echo json_encode($offer_arr);
}
else {

    // set response code - 404 Not found
    http_response_code(404);

    // tell the user no offers found
    echo json_encode(
        array("message" => "No offers found.")
    );
}

// no offers found will be here