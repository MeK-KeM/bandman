<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// include database and object files
include_once '../config/database.php';
include_once '../objects/offer.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare offers object
$offers = new Offer($db);

// get id of offers to be edited
$data = json_decode(file_get_contents("php://input"));

// set offers property values
$offers->id = $data->id;
$offers->title = $data->title;
$offers->sender_id = $data->sender_id;
$offers->receiver_id = $data->receiver_id;
$offers->start_date = $data->start_date;
$offers->finish_date = $data->finish_date;
$offers->description = $data->description;
$offers->status = $data->status;

$newAttributes = array();
foreach ($data as $field => $val) {
    if ($field != 'id') {
        array_push($newAttributes, $field);
    }
}

// update the offers
if($offers->update($newAttributes)){

    // set response code - 201 ok
    http_response_code(201);

    // tell the user
    echo json_encode(array("result" => "1"));
}

// if unable to update the offers, tell the user
else{

    // set response code - 503 service unavailable
    http_response_code(503);

    // tell the user
    echo json_encode(array("result" => "0",
        "new_attributes" => $newAttributes));
}
?>