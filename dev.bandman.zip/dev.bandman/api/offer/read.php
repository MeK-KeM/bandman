<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// database connection will be here

// include database and object files
include_once '../config/database.php';
include_once '../objects/offer.php';

// instantiate database and offer object
$database = new Database();
$db = $database->getConnection();

// initialize object
$offer = new Offer($db);

// read offers will be here
$user_id = isset($_GET['id']) ? $_GET['id'] : die();
// query offers
$stmt = $offer->read($user_id);
$num = $stmt->rowCount();


// check if more than 0 record found
if($num>0){

    // offers array
    $offers_arr=array();
    $offers_arr["records"]=array();

    // retrieve our table contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        // extract row
        // this will make $row['name'] to
        // just $name only
        extract($row);
        array_push($offers_arr["records"], array(
            "id" => $id,
            "title" => $title,
            "sender_id" => $sender_id,
            "receiver_id" => $receiver_id,
            "start_date" => $start_date,
            "finish_date" => $finish_date,
            "description" => html_entity_decode($description),
            "status" => $status
        ));
    }

    // set response code - 201 OK
    http_response_code(201);

    // show offers data in json format
    echo json_encode($offers_arr);
} else {

    // set response code - 404 Not found
    http_response_code(404);

    // tell the user no offers found
    echo json_encode(
        array("message" => "No offers found.")
    );
}

// no offers found will be here