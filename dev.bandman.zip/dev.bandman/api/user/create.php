<?php
/*
 * 0 couldn't create
 * 1 success
 * -1 bad request
 * -2 user exists
 * */
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// get database connection
include_once '../config/database.php';

// instantiate product object
include_once '../objects/user.php';

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

// get posted data
$data = json_decode(file_get_contents("php://input"));

// query user
$stmt = $user->read();

// make sure data is not empty
if(
    !empty($data->name) &&
    !empty($data->phone) &&
    !empty($data->pass)
){

    // set product property values
    $user->id = $data->id;
    $user->name = $data->name;
    $user->phone = $data->phone;
    $user->pass = $data->pass;
    $access = true;


    $names = array();

    // retrieve our table contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        // extract row
        // this will make $row['name'] to
        // just $name only
        extract($row);

        if ($user->name == $name) {
            $access = false;
        }
    }


    // create the product

    if ($access) {
        if($user->create()){
            // set response code - 201 created
            http_response_code(201);

            // tell the user
            echo json_encode(array("result" => "1"));
        } else {

            // set response code - 503 service unavailable
            http_response_code(503);

            // tell the user
            echo json_encode(array("result" => "0"));
        }
    }

    // if unable to create the product, tell the user
    else {
        // set response code - 200 ok
        http_response_code(200);

        echo json_encode(array("result" => "-2"));
    }

}

// tell the user data is incomplete
else{

    // set response code - 400 bad request
    http_response_code(400);

    // tell the user
    echo json_encode(array("result" => "-1"));
}
?>