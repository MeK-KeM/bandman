<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// include database and object files
include_once '../config/database.php';
include_once '../objects/user.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare product object
$user = new User($db);

// get id of product to be edited
$data = json_decode(file_get_contents("php://input"));


// set product property values
$user->name = $data->name;
$user->phone = $data->phone;
$user->bio = $data->bio;
$user->pass = $data->pass;
$user->firstname = $data->firstname;

$newAttributes = array();
foreach ($data as $field => $val) {
    if ($field != 'name') {
        array_push($newAttributes, $field);
    }
}



// update the product
if($user->update($newAttributes)){

    // set response code - 201 success
    http_response_code(201);

    // tell the user
    echo json_encode(array(
        "result" => "1"
    ));
}

// if unable to update the product, tell the user
else{

    // set response code - 503 service unavailable
    http_response_code(503);

    // tell the user
    echo json_encode(array(
        "result" => "-1"
    ));
}
?>