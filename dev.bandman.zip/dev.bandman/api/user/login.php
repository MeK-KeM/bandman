<?php
/*
 *
 * */
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// database connection will be here

// include database and object files
include_once '../config/database.php';
include_once '../objects/user.php';

// instantiate database and product object
$database = new Database();
$db = $database->getConnection();

// initialize object
$user = new User($db);

// read user will be here
// query user
$stmt = $user->read();


// get posted data
$data = json_decode(file_get_contents("php://input"));

// check if more than 0 record found
if( $data->name && $data->pass ){

    // user array
    $users_arr=array();

    $access = false;


    // retrieve our table contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        // extract row
        // this will make $row['name'] to
        // just $name only
        extract($row);

        if ($name == $data->name && $pass == $data->pass) {
            $access = true;
        }
    }

    if ( $access ) {
        // set response code - 200 OK
        http_response_code(201);

        echo json_encode(
            array("result" => "1")
        );
    } else {
        // set response code - 200 OK
        http_response_code(200);

        echo json_encode(
            array("result" => "-1")
        );
    }


} else {

    // set response code - 404 Not found
    http_response_code(404);

    // tell the user no user found
    echo json_encode(
        array("result" => "0")
    );
}

// no user found will be here