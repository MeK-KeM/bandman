<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// database connection will be here

// include database and object files
include_once '../config/database.php';
include_once '../objects/dashboard.php';
include_once '../objects/offer.php';

// instantiate database and dashboard object
$database = new Database();
$db = $database->getConnection();

// initialize object
$dashboard = new dashboard($db);

// read dashboards will be here
$user_id = isset($_GET['id']) ? $_GET['id'] : die();
// query dashboards
$stmt = $dashboard->read($user_id);
$num = $stmt->rowCount();


// check if more than 0 record found
if($num>0){

    // dashboards array
    $dashboards_arr=array();
    $dashboards_arr["records"]=array();

    // retrieve our table contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        $offer_data = '';
        // extract row
        // this will make $row['name'] to
        // just $name only
        extract($row);

        $tmpOffer = new Offer($db);

        $tmpOffer->id = $offer_id;
        $tmpOffer->readOne();
        $offer_data = $tmpOffer;

        array_push($dashboards_arr["records"], array(
            "id" => $id,
            "offer_id" => $offer_id,
            "sender_id" => $sender_id,
            "receiver_id" => $receiver_id,
            "offer_data" => $offer_data
        ));
    }

    // set response code - 201 OK
    http_response_code(201);

    // show dashboards data in json format
    echo json_encode($dashboards_arr);
} else {

    // set response code - 404 Not found
    http_response_code(404);

    // tell the user no dashboards found
    echo json_encode(
        array("message" => "No dashboards found.")
    );
}

// no dashboards found will be here